# FitTrack Android

An offline-first Android fitness tracker wrapped in a native Android WebView shell.

## Features
- Food diary with calories, protein, carbs and fat
- Daily calorie and macro targets
- Workout log with sets, reps and weight
- Per-exercise history and estimated 1RM trend (Epley estimate)
- Bodyweight history
- Steps tracking
- Dark/light theme toggle
- Local device storage; no account or network required

## Build APK
This environment did not have the Android SDK or Gradle installed, so it could not compile or verify an APK here. The complete Android Studio project is included.

1. Install Android Studio.
2. Open this `FitTrackAndroid` folder.
3. Allow Android Studio to install the required Android Gradle Plugin / SDK (compile SDK 35).
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the APK location, usually `app/build/outputs/apk/debug/app-debug.apk`.

Data is stored locally in the app's WebView local storage. Uninstalling the app or clearing its storage can erase it. Export/backup is not yet included.
